from django.apps import AppConfig


class ManageConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "apps.manage"
    label = "manage"
    verbose_name = "Owner portal"
